import { NgModule } from "@angular/core";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";
import { AppComponent } from "./app.component";
import { Desktop2Component } from "./export-result/desktop-2/desktop-2.component";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { InputIconModule } from 'primeng/inputicon';
import { IconFieldModule } from 'primeng/iconfield';
import { InputTextModule } from 'primeng/inputtext';
@NgModule({
  declarations: [AppComponent, Desktop2Component],
  imports: [BrowserModule, BrowserAnimationsModule, FormsModule, NgbModule,InputTextModule,IconFieldModule,InputIconModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
