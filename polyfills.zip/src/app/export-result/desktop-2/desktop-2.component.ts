import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
import { NgbCarouselConfig } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: "app-desktop-2",
  templateUrl: "./desktop-2.component.html",
  styleUrls: ["./desktop-2.component.scss"],
  providers: [NgbCarouselConfig],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Desktop2Component {
  showNavigationArrows = false;
	showNavigationIndicators = false;
	images = [700, 533, 807, 124].map((n) => `https://picsum.photos/id/${n}/900/500`);

  constructor(config: NgbCarouselConfig) {
		// customize default values of carousels used by this component tree
		config.interval = 20000;
		config.wrap = true;
		config.keyboard = false;
		config.pauseOnHover = false;
    config.showNavigationArrows = true;
    config.showNavigationIndicators = true
	}
}